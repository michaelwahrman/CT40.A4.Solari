# CT40.A4.Solari: generates CT40.A4.Solari.schedule.json (the sample schedule). Optional; you can edit the JSON directly.
import json, os
def t(m):  # minutes from midnight -> "h:mm AM"
    h, mm = divmod(m, 60); ap = "AM" if h < 12 else "PM"; h12 = h % 12 or 12
    return f"{h12}:{mm:02d} {ap}"
def hm(s):
    t, ap = s.split(); parts = [int(x) for x in t.split(":")] + [0]
    h = parts[0] % 12 + (12 if ap == "PM" else 0)
    return h*3600 + parts[1]*60 + parts[2]
trains = [
 # row, train, destination, gate, scheduled, [(offset_from_start or abs time, status)...], clear_at
 (1, "North Carolina Special", "RALEIGH", "12", "10:01 AM", [("9:30 AM","ON TIME"),("9:48 AM","DELAYED"),("10:12 AM","BOARDING"),("10:24 AM","DEPARTED")], "10:32 AM"),
 (2, "Silver Meteor", "MIAMI", "7", "9:52 AM", [("9:30 AM","BOARDING"),("9:47 AM","LAST CALL"),("9:53 AM","DEPARTED")], "10:00 AM"),
 (3, "Vermonter", "ST ALBANS", "3", "10:15 AM", [("9:30 AM","ON TIME"),("10:00 AM","BOARDING"),("10:16 AM","DEPARTED")], "10:24 AM"),
 (4, "Lake Shore Limited", "CHICAGO", "9", "10:40 AM", [("9:30 AM","ON TIME"),("10:05 AM","DELAYED"),("10:50 AM","BOARDING"),("11:02 AM","DEPARTED")], "11:10 AM"),
 (5, "Keystone Service", "HARRISBURG", "5", "10:05 AM", [("9:30 AM","ARRIVING"),("9:44 AM","ARRIVED"),("9:50 AM","BOARDING"),("10:06 AM","DEPARTED")], "10:14 AM"),
 (6, "Crescent", "NEW ORLEANS", "11", "11:05 AM", [("9:30 AM","ON TIME"),("10:48 AM","BOARDING"),("11:06 AM","DEPARTED")], "11:14 AM"),
 (7, "Cardinal", "CHICAGO", "14", "11:30 AM", [("9:30 AM","ON TIME"),("10:40 AM","DELAYED"),("11:20 AM","CANCELLED")], "11:50 AM"),
 (8, "Palmetto", "SAVANNAH", "2", "11:45 AM", [("9:30 AM","ON TIME"),("9:31:40 AM","DELAYED"),("9:52 AM","ON TIME"),("11:26 AM","BOARDING"),("11:46 AM","DEPARTED")], "11:54 AM"),
 # replacements in freed rows
 (2, "Northeast Regional", "BOSTON", "6", "10:35 AM", [("10:02 AM","ARRIVING"),("10:18 AM","ARRIVED"),("10:20 AM","BOARDING"),("10:36 AM","DEPARTED")], "10:44 AM"),
 (5, "Acela", "WASHINGTON", "1", "10:55 AM", [("10:16 AM","ON TIME"),("10:38 AM","BOARDING"),("10:56 AM","DEPARTED")], "11:04 AM"),
 (3, "Ethan Allen Express", "RUTLAND", "4", "11:20 AM", [("10:26 AM","ON TIME"),("10:58 AM","DELAYED"),("11:32 AM","BOARDING"),("11:41 AM","DEPARTED")], "11:48 AM"),
 (1, "Carolinian", "CHARLOTTE", "8", "11:15 AM", [("10:34 AM","ARRIVING"),("10:52 AM","ARRIVED"),("10:58 AM","BOARDING"),("11:16 AM","DEPARTED")], "11:24 AM"),
 (2, "Maple Leaf", "TORONTO", "10", "12:05 PM", [("10:46 AM","ON TIME"),("11:47 AM","BOARDING"),("12:06 PM","DEPARTED")], "12:14 PM"),
 (5, "Adirondack", "MONTREAL", "15", "12:10 PM", [("11:06 AM","ON TIME"),("11:30 AM","DELAYED"),("12:20 PM","BOARDING"),("12:28 PM","DEPARTED")], None),
 (4, "Pennsylvanian", "PITTSBURGH", "3", "12:20 PM", [("11:12 AM","ON TIME"),("12:02 PM","BOARDING")], None),
 (6, "Empire Service", "ALBANY", "9", "12:25 PM", [("11:16 AM","ARRIVING"),("11:34 AM","ARRIVED"),("12:08 PM","BOARDING")], None),
 (1, "Night Owl", "BOSTON", "12", "12:30 PM", [("11:26 AM","ON TIME")], None),
]
events = []
for row, name, dest, gate, sched, stats, clear in trains:
    first = True
    for at, st in stats:
        if first:
            events.append({"at": at, "row": row, "set": {"time": sched, "description": name, "status": st, "destination": dest, "gate": gate}})
            first = False
        else:
            events.append({"at": at, "row": row, "set": {"status": st}})
    if clear:
        events.append({"at": clear, "row": row, "clear": True})
extra = [
  # the opening burst, seconds apart, so something happens right away at real time
  {"at": "9:30:05 AM", "row": 2, "set": {"status": "LAST CALL"}},
  {"at": "9:30:11 AM", "row": 5, "set": {"status": "ARRIVED"}},
  {"at": "9:30:18 AM", "row": 7, "set": {"status": "DELAYED", "time": "11:48 AM"}},
  {"at": "9:30:26 AM", "row": 4, "set": {"gate": "10"}},
  {"at": "9:30:34 AM", "row": 1, "set": {"status": "DELAYED"}},
  {"at": "9:30:43 AM", "row": 3, "set": {"gate": "6"}},
  {"at": "9:30:52 AM", "row": 1, "set": {"time": "10:20 AM"}},
  {"at": "9:31:05 AM", "row": 6, "set": {"status": "DELAYED"}},
  {"at": "9:31:20 AM", "row": 2, "set": {"gate": "9"}},
  # then something every minute or so for the first quarter hour
  {"at": "9:32:10 AM", "row": 6, "set": {"status": "ON TIME"}},
  {"at": "9:33:00 AM", "row": 4, "set": {"status": "DELAYED", "time": "10:55 AM"}},
  {"at": "9:34:00 AM", "row": 3, "set": {"status": "BOARDING"}},
  {"at": "9:35:15 AM", "row": 5, "set": {"gate": "4"}},
  {"at": "9:36:30 AM", "row": 7, "set": {"time": "12:05 PM"}},
  {"at": "9:37:45 AM", "row": 3, "set": {"status": "ON TIME"}},
  {"at": "9:39:00 AM", "row": 8, "set": {"gate": "16"}},
  {"at": "9:40:30 AM", "row": 1, "set": {"gate": "11"}},
  {"at": "9:42:00 AM", "row": 6, "set": {"gate": "13"}},
  {"at": "9:43:30 AM", "row": 4, "set": {"gate": "8"}},
]
events += extra
events.sort(key=lambda e: (hm(e["at"]), e["row"], 0 if e.get("clear") else 1))
sched = {
  "name": "CT40.A4.Solari",
  "about": "What the CT40.A4.Solari sign says, and when. Times are on the master clock, as 'h:mm AM' or 'h:mm:ss AM'. 'labels' are the column headings shown at the top of the sign (no split line). Each event sets one or more fields of a row (rows count from 1), or clears the row. Events apply in time order; later events overwrite earlier ones.",
  "title": "TRAINS",
  "labels": {"time": "TIME", "description": "TRAIN", "status": "STATUS", "destination": "DESTINATION", "gate": "TRACK"},
  "rows": 8,
  "clock": {"start": "9:30 AM", "end": "12:30 PM", "speed": 1, "loop": True, "autoStart": True, "autoStartDelaySeconds": 2, "showSeconds": True,
            "note": "speed = seconds of master-clock time per real second (1 = real time, the default; 20 = one clock minute every 3 real seconds). autoStart runs the clock by itself autoStartDelaySeconds after loading. loop starts over at the end. showSeconds: master clock as h:mm:ss AM (true) or h:mm AM (false)."},
  "events": events,
}
json.dump(sched, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "CT40.A4.Solari.schedule.json"), "w"), indent=2)
print(len(events), "events")

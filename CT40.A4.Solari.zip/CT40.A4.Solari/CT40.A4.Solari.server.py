"""
CT40.A4.Solari local launcher.

Serves this folder on http://127.0.0.1 (this computer only) and opens the sign in the
default browser. Browsers refuse to let a page opened straight from disk read its JSON
files, so the sign needs this tiny server. Uses only the Python standard library.

Usage:  python CT40.A4.Solari.server.py [port]      (Ctrl+C to stop)
"""
import functools
import http.server
import os
import socketserver
import sys
import threading
import webbrowser

NAME = "CT40.A4.Solari"
HERE = os.path.dirname(os.path.abspath(__file__))


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      ".js": "text/javascript", ".json": "application/json"}

    def end_headers(self):
        # always serve fresh copies so edits to the JSON files show up on reload
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, fmt, *args):
        pass


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 0   # 0 = any free port
    handler = functools.partial(Handler, directory=HERE)
    with socketserver.TCPServer(("127.0.0.1", port), handler) as httpd:
        url = f"http://127.0.0.1:{httpd.server_address[1]}/{NAME}.html"
        print(f"{NAME} is running at {url}")
        print("Leave this window open while you use the sign. Press Ctrl+C to stop.")
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopped.")


if __name__ == "__main__":
    main()

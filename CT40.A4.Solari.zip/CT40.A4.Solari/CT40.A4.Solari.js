/*
 * CT40.A4.Solari — a split-flap ("Solari") departure sign in WebGL / three.js.
 *
 * Reads two JSON files that sit next to this script:
 *   CT40.A4.Solari.fields.json    what the columns are (type and width of each field)
 *   CT40.A4.Solari.schedule.json  column labels, the master clock, and what each row
 *                                 says at what time
 *
 * Every character is a physical flap on a drum. A change never jumps: the drum steps
 * forward one flap at a time through every in-between character (A -> B -> C -> D -> E)
 * until it reaches the new one, exactly like the real thing.
 *
 * three.js is loaded locally (vendor/CT40.A4.Solari.three.min.js), so no internet is needed.
 */
(function () {
  'use strict';

  const NAME = 'CT40.A4.Solari';
  const THREE = window.THREE;
  const FIELDS_URL = 'CT40.A4.Solari.fields.json';
  const SCHEDULE_URL = 'CT40.A4.Solari.schedule.json';

  // Geometry of one flap unit, in world units (set from display.geometry in the fields file)
  let CELL_W = 0.88;
  const CELL_H = 1.0;
  let PITCH_X = 0.90;
  let PITCH_Y = 1.36;

  // ------------------------------------------------------------------ time helpers
  /** "9:30 AM", "09:30 am", "12:05 PM", "21:15" -> seconds after midnight */
  function parseTime(str) {
    if (typeof str === 'number') return str;
    const m = String(str).trim().match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([AaPp][Mm])?$/);
    if (!m) throw new Error('Cannot read time "' + str + '" (use e.g. "9:30 AM" or "21:30")');
    let h = parseInt(m[1], 10);
    const min = parseInt(m[2], 10);
    const sec = m[3] ? parseInt(m[3], 10) : 0;
    if (m[4]) {
      const pm = m[4].toUpperCase() === 'PM';
      if (h === 12) h = 0;
      if (pm) h += 12;
    }
    return h * 3600 + min * 60 + sec;
  }

  /** seconds -> 8 characters, "hh:mm AM" with the hour right-aligned: " 9:30 AM" */
  function clockText(seconds) {
    const total = Math.floor(seconds / 60);
    const h24 = Math.floor(total / 60) % 24;
    const mm = total % 60;
    const h12 = (h24 % 12) || 12;
    const hs = (h12 < 10 ? ' ' : '') + h12;
    return hs + ':' + (mm < 10 ? '0' : '') + mm + ' ' + (h24 < 12 ? 'AM' : 'PM');
  }

  /** seconds -> "9:30:07 AM" (for the status bar) */
  function clockTextSeconds(seconds) {
    const s = Math.floor(seconds) % 60;
    const t = clockText(seconds).trim();
    return t.slice(0, -3) + ':' + (s < 10 ? '0' : '') + s + t.slice(-3);
  }

  function hexToVec3(hex) {
    const c = String(hex).replace('#', '');
    const n = parseInt(c.length === 3 ? c.split('').map(x => x + x).join('') : c, 16);
    return new THREE.Vector3(((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255);
  }

  // ------------------------------------------------------------------ field types
  // Each field type turns into a list of drums (one per flap). Index 0 of every drum is
  // blank so that a cleared row shows nothing.
  function drumsForField(field, display) {
    const alnum = Array.from(display.alphanumericDrum || ' ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789');
    const numeric = Array.from(display.numericDrum || ' 0123456789');
    switch (field.type) {
      case 'time':
        return [
          [' ', '1'],
          Array.from(' 0123456789'),
          [' ', ':'],
          Array.from(' 012345'),
          Array.from(' 0123456789'),
          [' '],
          [' ', 'A', 'P'],
          [' ', 'M'],
        ];
      case 'numeric':
        return Array.from({ length: field.length || 4 }, () => numeric.slice());
      case 'alphanumeric':
      default:
        return Array.from({ length: field.length || 10 }, () => alnum.slice());
    }
  }

  /** The text a field should show, as one character per flap */
  function fieldText(field, value, display) {
    const n = field.type === 'time' ? 8 : (field.length || 10);
    if (value === undefined || value === null || value === '') return ' '.repeat(n);
    let s;
    if (field.type === 'time') {
      s = clockText(parseTime(value));
    } else {
      s = String(value);
      if (display.uppercase !== false) s = s.toUpperCase();
      const align = field.align || (field.type === 'numeric' ? 'right' : 'left');
      if (s.length > n) s = s.slice(0, n);
      s = align === 'right' ? s.padStart(n, ' ') : s.padEnd(n, ' ');
    }
    return s;
  }

  // ------------------------------------------------------------------ glyph atlas
  function buildAtlas(chars, display) {
    const GH = 144;
    const GW = Math.round(GH * CELL_W / CELL_H);         // atlas cell has the flap's shape
    const fontSize = display.fontSize || 100;
    const glyphWidth = display.glyphWidth || 0.8;        // widest glyph, as a share of the flap
    const cols = 16;
    const rows = Math.ceil(chars.length / cols);
    const canvas = document.createElement('canvas');
    canvas.width = cols * GW;
    canvas.height = rows * GH;
    const g = canvas.getContext('2d');
    g.clearRect(0, 0, canvas.width, canvas.height);
    g.fillStyle = '#ffffff';
    g.textAlign = 'center';
    g.textBaseline = 'alphabetic';
    const font = (display.font || '600 {size}px Helvetica, Arial, sans-serif');
    g.font = font.replace('{size}', fontSize);
    // Center every character on the cap height, so the split line runs through the
    // middle of the capitals just like on a real Solari board
    const capHeight = g.measureText('H').actualBoundingBoxAscent;
    chars.forEach((ch, i) => {
      if (ch === ' ') return;
      const cx = (i % cols) * GW + GW / 2;
      const cy = Math.floor(i / cols) * GH + GH / 2;
      const w = g.measureText(ch).width;
      // wide glyphs (M, W) are narrowed, not shrunk, so they keep the full cap height
      const squeeze = Math.min(display.condense || 1, (GW * glyphWidth) / w);
      g.setTransform(squeeze, 0, 0, 1, cx, cy + capHeight / 2);
      g.fillText(ch, 0, 0);
    });
    g.setTransform(1, 0, 0, 1, 0, 0);
    const tex = new THREE.CanvasTexture(canvas);
    tex.generateMipmaps = true;
    tex.minFilter = THREE.LinearMipmapLinearFilter;
    tex.magFilter = THREE.LinearFilter;
    tex.anisotropy = 4;
    const index = new Map(chars.map((c, i) => [c, i]));
    return { texture: tex, cols, rows, index };
  }

  // ------------------------------------------------------------------ flap shaders
  const VERT = /* glsl */`
    attribute vec3 aOffset;
    attribute float aCur;
    attribute float aNext;
    attribute float aAngle;
    attribute float aScale;
    uniform float uPart;          // 0 static top, 1 static bottom, 2 falling flap
    uniform vec2 uCell;           // flap width, height
    varying vec2 vUv;
    varying float vCur;
    varying float vNext;
    varying float vShade;
    varying float vT;
    void main() {
      vec3 p = position;          // a half-flap: y from 0 (hinge) to h/2 (top edge)
      vT = p.y / (uCell.y * 0.5);
      vShade = 1.0;
      if (uPart > 0.5 && uPart < 1.5) {
        p.y = -p.y;               // bottom half hangs below the hinge
      } else if (uPart > 1.5) {
        float a = aAngle;         // flap falls forward around the hinge
        float y = p.y;
        p.y = y * cos(a);
        p.z = y * sin(a) + 0.004;
        vShade = 1.0 - 0.45 * sin(a);
      }
      vUv = uv;
      vCur = aCur;
      vNext = aNext;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(p * aScale + aOffset, 1.0);
    }
  `;

  const FRAG = /* glsl */`
    uniform sampler2D uAtlas;
    uniform vec2 uGrid;           // atlas columns, rows
    uniform vec3 uFlap;           // flap color at the top edge
    uniform vec3 uFlap2;          // flap color at the bottom edge
    uniform vec3 uChar;
    uniform vec3 uLine;
    uniform vec3 uBorder;         // thin frame around every flap
    uniform float uBorderW;       // frame width, share of the flap (0 = none)
    uniform vec3 uDiag;           // the diagonal bevel across each flap
    uniform vec3 uDiagHi;
    uniform float uDiagOn;
    uniform float uPart;
    uniform float uLineWidth;     // in half-flap units
    varying vec2 vUv;
    varying float vCur;
    varying float vNext;
    varying float vShade;
    varying float vT;

    float glyph(float idx, float u, float v) {
      float col = mod(idx, uGrid.x);
      float row = floor(idx / uGrid.x + 0.001);
      vec2 tuv = vec2((col + u) / uGrid.x, 1.0 - (row + 1.0 - v) / uGrid.y);
      return texture2D(uAtlas, tuv).a;
    }

    void main() {
      float idx;
      float v;
      bool upper;
      if (uPart < 0.5) {                 // static top: the character coming next
        idx = vNext; v = 0.5 + 0.5 * vT; upper = true;
      } else if (uPart < 1.5) {          // static bottom: the current character
        idx = vCur;  v = 0.5 - 0.5 * vT; upper = false;
      } else if (gl_FrontFacing) {       // falling flap, front: current top half
        idx = vCur;  v = 0.5 + 0.5 * vT; upper = true;
      } else {                           // falling flap, back: next bottom half
        idx = vNext; v = 0.5 - 0.5 * vT; upper = false;
      }
      float a = glyph(idx, vUv.x, v);
      // flap face: a gentle top-to-bottom gradient (v: 0 bottom .. 1 top of the whole flap)
      vec3 col = mix(uFlap2, uFlap, v);
      // diagonal bevel from the top-left to the bottom-right corner, behind the letter
      if (uDiagOn > 0.5) {
        float dd = vUv.x + v - 1.0;
        float aa = fwidth(dd) * 1.2;
        col = mix(col, uDiag, 1.0 - smoothstep(0.012, 0.012 + aa, abs(dd)));
        col = mix(col, uDiagHi, (1.0 - smoothstep(0.008, 0.008 + aa, abs(dd - 0.03))) * 0.8);
      }
      col = mix(col, uChar, a);
      // subtle curvature shading toward the outer edges of each half
      col *= 1.0 - 0.10 * vT * vT;
      // frame around the flap
      if (uBorderW > 0.0) {
        float e = min(min(vUv.x, 1.0 - vUv.x), min(v, 1.0 - v));
        if (e < uBorderW) col = uBorder;
      }
      // the gray line where the two halves meet
      if (vT < uLineWidth) col = uLine;
      gl_FragColor = vec4(col * vShade, 1.0);
    }
  `;

  // ------------------------------------------------------------------ the board
  class Board {
    constructor(fieldsDoc, scheduleDoc, host) {
      this.fieldsDoc = fieldsDoc;
      this.schedule = scheduleDoc;
      this.display = Object.assign({
        uppercase: true, flipMilliseconds: 160, maxStartDelayMilliseconds: 400, colors: {}
      }, fieldsDoc.display || {});
      const geo = this.display.geometry || {};
      if (geo.flapWidth) CELL_W = geo.flapWidth;
      if (geo.pitchX) PITCH_X = geo.pitchX;
      if (geo.pitchY) PITCH_Y = geo.pitchY;
      this.colors = Object.assign({
        background: '#000000', flap: '#161616', character: '#f2f0e6',
        splitLine: '#6e6e6e', label: '#c9c6b8'
      }, this.display.colors || {});
      this.fields = fieldsDoc.fields;
      this.rows = scheduleDoc.rows || 8;
      this.validate();
      this.prepareSchedule();
      this.buildCells();
      this.buildScene(host);
      this.reset();
    }

    validate() {
      const ids = new Set();
      for (const f of this.fields) {
        if (!f.id) throw new Error('Every field needs an "id"');
        if (ids.has(f.id)) throw new Error('Duplicate field id "' + f.id + '"');
        ids.add(f.id);
        if (!['alphanumeric', 'time', 'numeric'].includes(f.type)) {
          throw new Error('Field "' + f.id + '" has unknown type "' + f.type + '"');
        }
      }
      this.fieldIds = ids;
    }

    prepareSchedule() {
      const s = this.schedule;
      const clock = s.clock || {};
      this.clockStart = parseTime(clock.start || '0:00');
      this.clockEnd = clock.end ? parseTime(clock.end) : this.clockStart + 24 * 3600;
      if (this.clockEnd <= this.clockStart) this.clockEnd += 24 * 3600;
      this.speed = clock.speed || 1;
      this.loop = !!clock.loop;
      this.events = (s.events || []).map((e, i) => {
        let at = parseTime(e.at);
        if (at < this.clockStart) at += 24 * 3600; // past midnight
        if (!Number.isInteger(e.row) || e.row < 1 || e.row > this.rows) {
          throw new Error('Event ' + (i + 1) + ' ("' + e.at + '") has row ' + e.row +
            ' but the sign has rows 1-' + this.rows);
        }
        for (const k of Object.keys(e.set || {})) {
          if (!this.fieldIds.has(k)) {
            throw new Error('Event ' + (i + 1) + ' ("' + e.at + '") sets unknown field "' + k + '"');
          }
        }
        return { at, order: i, row: e.row - 1, set: e.set || {}, clear: !!e.clear };
      }).sort((a, b) => a.at - b.at || a.order - b.order);
    }

    /** Row contents at a given master-clock time */
    stateAt(t) {
      const rows = Array.from({ length: this.rows }, () => ({}));
      for (const e of this.events) {
        if (e.at > t) break;
        if (e.clear) rows[e.row] = {};
        Object.assign(rows[e.row], e.set);
      }
      return rows;
    }

    buildCells() {
      this.cells = [];
      const addCell = (drum, x, y, scale) => {
        const c = { drum, x, y, scale: scale || 1, cur: 0, next: 0, target: 0, t0: -1, wait: -1, angle: 0 };
        this.cells.push(c);
        return c;
      };
      // Columns: fields left to right with one blank flap-width between them
      let col = 0;
      this.fieldLayout = this.fields.map((f) => {
        const drums = drumsForField(f, this.display);
        const start = col;
        col += drums.length + 1;
        return { field: f, drums, start, width: drums.length };
      });
      this.totalCols = col - 1;
      const x0 = -((this.totalCols - 1) * PITCH_X) / 2;
      this.x0 = x0;

      // Rows of the board
      this.rowCells = [];
      for (let r = 0; r < this.rows; r++) {
        const y = -r * PITCH_Y;
        const perField = {};
        for (const L of this.fieldLayout) {
          perField[L.field.id] = L.drums.map((d, i) => addCell(d, x0 + (L.start + i) * PITCH_X, y));
        }
        this.rowCells.push(perField);
      }

      // Master clock, top center
      // Master clock: h:mm:ss AM by default (clock.showSeconds), so real time visibly ticks
      this.clockSeconds = (this.schedule.clock || {}).showSeconds !== false;
      this.clockField = { id: '__clock', type: 'time' };
      const clockDrums = this.clockSeconds ? [
        [' ', '1'], Array.from(' 0123456789'), [' ', ':'], Array.from(' 012345'),
        Array.from(' 0123456789'), [' ', ':'], Array.from(' 012345'), Array.from(' 0123456789'),
        [' '], [' ', 'A', 'P'], [' ', 'M'],
      ] : drumsForField(this.clockField, this.display);
      this.clockScale = 1.4;
      this.clockY = 1.2 + PITCH_Y * this.clockScale;
      const cp = PITCH_X * this.clockScale;
      const cx0 = -((clockDrums.length - 1) * cp) / 2;
      this.clockCells = clockDrums.map((d, i) => addCell(d, cx0 + i * cp, this.clockY, this.clockScale));

      // Atlas of every character any drum can show
      const chars = new Set([' ']);
      for (const c of this.cells) c.drum.forEach(ch => chars.add(ch));
      this.atlas = buildAtlas(Array.from(chars), this.display);
      for (const c of this.cells) c.glyph = c.drum.map(ch => this.atlas.index.get(ch));
    }

    buildScene(host) {
      const renderer = new THREE.WebGLRenderer({ antialias: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setClearColor(this.colors.background);
      host.appendChild(renderer.domElement);
      this.renderer = renderer;
      this.host = host;
      this.scene = new THREE.Scene();
      this.camera = new THREE.OrthographicCamera(-10, 10, 10, -10, -10, 10);
      this.camera.position.z = 5;

      const n = this.cells.length;
      this.aOffset = new THREE.InstancedBufferAttribute(new Float32Array(n * 3), 3);
      this.aCur = new THREE.InstancedBufferAttribute(new Float32Array(n), 1);
      this.aNext = new THREE.InstancedBufferAttribute(new Float32Array(n), 1);
      this.aAngle = new THREE.InstancedBufferAttribute(new Float32Array(n), 1);
      this.aScale = new THREE.InstancedBufferAttribute(new Float32Array(n), 1);
      this.cells.forEach((c, i) => { this.aOffset.setXYZ(i, c.x, c.y, 0); this.aScale.setX(i, c.scale); });
      [this.aCur, this.aNext, this.aAngle].forEach(a => a.setUsage(THREE.DynamicDrawUsage));

      const half = new THREE.PlaneGeometry(CELL_W, CELL_H / 2);
      half.translate(0, CELL_H / 4, 0);
      const uniformsBase = {
        uAtlas: { value: this.atlas.texture },
        uGrid: { value: new THREE.Vector2(this.atlas.cols, this.atlas.rows) },
        uFlap: { value: hexToVec3(this.colors.flap) },
        uFlap2: { value: hexToVec3(this.colors.flapBottom || this.colors.flap) },
        uBorder: { value: hexToVec3(this.colors.border || this.colors.background) },
        uBorderW: { value: this.colors.border ? (this.display.borderWidth || 0.04) : 0.0 },
        uDiag: { value: hexToVec3(this.colors.diagonal || this.colors.flap) },
        uDiagHi: { value: hexToVec3(this.colors.diagonalHighlight || this.colors.flap) },
        uDiagOn: { value: this.colors.diagonal ? 1.0 : 0.0 },
        uChar: { value: hexToVec3(this.colors.character) },
        uLine: { value: hexToVec3(this.colors.splitLine) },
        uCell: { value: new THREE.Vector2(CELL_W, CELL_H) },
        uLineWidth: { value: 0.035 },
      };
      for (let part = 0; part < 3; part++) {
        const geo = new THREE.InstancedBufferGeometry();
        geo.index = half.index;
        geo.setAttribute('position', half.getAttribute('position'));
        geo.setAttribute('uv', half.getAttribute('uv'));
        geo.setAttribute('aOffset', this.aOffset);
        geo.setAttribute('aCur', this.aCur);
        geo.setAttribute('aNext', this.aNext);
        geo.setAttribute('aAngle', this.aAngle);
        geo.setAttribute('aScale', this.aScale);
        geo.instanceCount = n;
        const mat = new THREE.ShaderMaterial({
          vertexShader: VERT,
          fragmentShader: FRAG,
          uniforms: Object.assign({ uPart: { value: part } }, uniformsBase),
          side: THREE.DoubleSide,
        });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.frustumCulled = false;
        mesh.renderOrder = part;
        this.scene.add(mesh);
      }

      this.buildLabels();
      this.resize();
      window.addEventListener('resize', () => this.resize());
    }

    /** Plain text (no split line): column labels, the board title, the program name */
    textPlane(text, widthWorld, heightWorld, align, x, y, sizeScale) {
      const pxPerUnit = 160;
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(4, Math.ceil(widthWorld * pxPerUnit));
      canvas.height = Math.max(4, Math.ceil(heightWorld * pxPerUnit));
      const g = canvas.getContext('2d');
      const size = Math.floor(canvas.height * 0.62 * (sizeScale || 1));
      g.font = (this.display.labelFont || '500 {size}px Helvetica, Arial, sans-serif').replace('{size}', size);
      g.fillStyle = this.colors.label;
      g.textBaseline = 'middle';
      g.textAlign = align === 'right' ? 'right' : (align === 'center' ? 'center' : 'left');
      const tx = align === 'right' ? canvas.width - 2 : (align === 'center' ? canvas.width / 2 : 2);
      g.fillText(text, tx, canvas.height / 2);
      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.minFilter = THREE.LinearFilter;
      const mesh = new THREE.Mesh(
        new THREE.PlaneGeometry(widthWorld, heightWorld),
        new THREE.MeshBasicMaterial({ map: tex, transparent: true, toneMapped: false })
      );
      mesh.position.set(x, y, 0);
      this.scene.add(mesh);
      return mesh;
    }

    buildLabels() {
      const labels = this.schedule.labels || {};
      const yLabel = CELL_H / 2 + 0.55;
      for (const L of this.fieldLayout) {
        const text = labels[L.field.id] !== undefined ? labels[L.field.id] : L.field.id.toUpperCase();
        const w = L.width * PITCH_X;
        const left = this.x0 + L.start * PITCH_X - CELL_W / 2;
        const align = L.field.align === 'right' ? 'right' : 'left';
        const pw = Math.max(w, 3.0);
        this.textPlane(String(text), pw, 0.9, align,
          align === 'right' ? left + w - pw / 2 : left + pw / 2, yLabel, 1.0);
      }
      // Board title (top left) and the program's own name (top right)
      const leftEdge = this.x0 - CELL_W / 2;
      const rightEdge = this.x0 + (this.totalCols - 1) * PITCH_X + CELL_W / 2;
      if (this.schedule.title) {
        this.textPlane(String(this.schedule.title), 14, 1.1, 'left', leftEdge + 7, this.clockY, 1.0);
      }
      this.textPlane(NAME, 14, 0.9, 'right', rightEdge - 7, this.clockY, 0.9);
      this.bounds = {
        left: leftEdge - 0.6,
        right: rightEdge + 0.6,
        top: this.clockY + CELL_H * this.clockScale / 2 + 0.6,
        bottom: -(this.rows - 1) * PITCH_Y - CELL_H / 2 - 0.6,
      };
    }

    resize() {
      const w = this.host.clientWidth || window.innerWidth;
      const h = this.host.clientHeight || window.innerHeight;
      this.renderer.setSize(w, h);
      const b = this.bounds;
      const bw = b.right - b.left, bh = b.top - b.bottom;
      const aspect = w / h;
      let vw = bw, vh = bh;
      if (aspect > bw / bh) vw = bh * aspect; else vh = bw / aspect;
      const cx = (b.left + b.right) / 2, cy = (b.top + b.bottom) / 2;
      Object.assign(this.camera, { left: cx - vw / 2, right: cx + vw / 2, top: cy + vh / 2, bottom: cy - vh / 2 });
      this.camera.updateProjectionMatrix();
    }

    // ---------------- master clock control
    reset() {
      this.sim = this.clockStart;
      this.running = false;
      this.updateTargets(true);
    }
    forward() {
      if (this.sim >= this.clockEnd && !this.loop) this.sim = this.clockStart;
      this.running = true;
    }
    stop() { this.running = false; }

    /** Set every flap's destination from the schedule at the current master time */
    updateTargets(force) {
      const second = Math.floor(this.sim);
      if (!force && second === this.lastSecond) return;
      this.lastSecond = second;
      const state = this.stateAt(this.sim);
      state.forEach((row, r) => {
        for (const L of this.fieldLayout) {
          const text = fieldText(L.field, row[L.field.id], this.display);
          this.setCells(this.rowCells[r][L.field.id], text);
        }
      });
      this.setCells(this.clockCells, this.clockSeconds
        ? clockTextSeconds(this.sim).padStart(11, ' ') : clockText(this.sim));
    }

    setCells(cells, text) {
      const chars = Array.from(text);
      cells.forEach((c, i) => {
        const idx = c.drum.indexOf(chars[i] || ' ');
        c.target = idx < 0 ? 0 : idx;
      });
    }

    // ---------------- per-frame animation
    step(nowMs, dtSec) {
      if (this.running) {
        this.sim += dtSec * this.speed;
        if (this.sim >= this.clockEnd) {
          if (this.loop) this.sim = this.clockStart;
          else { this.sim = this.clockEnd; this.running = false; }
        }
      }
      this.updateTargets(false);

      const flipMs = this.display.flipMilliseconds || 160;
      const maxDelay = this.display.maxStartDelayMilliseconds || 0;
      let landed = 0;
      const cur = this.aCur.array, nxt = this.aNext.array, ang = this.aAngle.array;
      for (let i = 0; i < this.cells.length; i++) {
        const c = this.cells[i];
        if (c.t0 >= 0) {
          let p = (nowMs - c.t0) / flipMs;
          if (p >= 1) {
            c.cur = c.next;
            landed++;
            if (c.cur !== c.target) {
              // keep turning: next flap drops right away
              c.next = (c.cur + 1) % c.drum.length;
              c.t0 = nowMs;
              p = 0;
            } else {
              c.t0 = -1;
            }
          }
          c.angle = c.t0 >= 0 ? Math.PI * Math.pow(Math.min(p, 1), 1.7) : 0;
        } else if (c.cur !== c.target) {
          if (c.wait < 0) c.wait = nowMs + Math.random() * maxDelay;
          if (nowMs >= c.wait) {
            c.wait = -1;
            c.next = (c.cur + 1) % c.drum.length;  // always forward, one flap at a time
            c.t0 = nowMs;
            c.angle = 0;
          }
        }
        if (c.t0 < 0) { c.next = c.cur; c.angle = 0; }
        cur[i] = c.glyph[c.cur];
        nxt[i] = c.glyph[c.next];
        ang[i] = c.angle;
      }
      this.aCur.needsUpdate = true;
      this.aNext.needsUpdate = true;
      this.aAngle.needsUpdate = true;
      this.renderer.render(this.scene, this.camera);
      return landed;
    }

    busy() { return this.cells.some(c => c.cur !== c.target || c.t0 >= 0); }
  }

  // ------------------------------------------------------------------ sound
  /**
   * The flap sound: a harsh metal-on-metal "clack", like a metal stapler snapping shut.
   * It is synthesized at start-up, so no sound files are needed (see synthClack).
   * Eight slightly different variants are made so a busy board doesn't sound like a
   * machine gun. You can use a recording instead (e.g. your own stapler) by naming it in
   * the fields file: display.sound.sampleFile (WAV/MP3/OGG in this folder).
   */
  class Clacker {
    constructor(opts) {
      this.enabled = opts.enabled !== false;
      this.volume = opts.volume !== undefined ? opts.volume : 0.6;
      this.sampleFile = opts.sampleFile || null;
      this.maxVoicesPerFrame = opts.maxVoicesPerFrame || 5;
      this.ctx = null;
      this.buffers = [];
    }

    ensureContext() {
      if (this.ctx) return true;
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return false;
      this.ctx = new AC();
      // master volume -> compressor (keeps a full-board roll from clipping) -> speakers
      this.master = this.ctx.createGain();
      this.master.gain.value = this.volume;
      this.comp = this.ctx.createDynamicsCompressor();
      this.comp.threshold.value = -14;
      this.comp.knee.value = 8;
      this.comp.ratio.value = 6;
      this.comp.attack.value = 0.002;
      this.comp.release.value = 0.12;
      this.master.connect(this.comp).connect(this.ctx.destination);
      for (let v = 0; v < 8; v++) this.buffers.push(this.synthClack(v));
      if (this.sampleFile) this.loadSample(this.sampleFile);
      return true;
    }

    /**
     * Metal striking metal. What makes it sound like metal rather than wood is a bright,
     * inharmonic set of partials that keep ringing (tens to hundreds of ms), with closely
     * spaced pairs that beat against each other for a clangy shimmer. There is no low
     * "body" thump, and the attack is a very short, very bright click. A second strike 3-7 ms
     * later gives the stapler's double "ka-chak".
     */
    synthClack(variant) {
      const sr = this.ctx.sampleRate;
      const len = Math.floor(sr * 0.42);
      const buf = this.ctx.createBuffer(1, len, sr);
      const d = buf.getChannelData(0);
      const rnd = (a, b) => a + Math.random() * (b - a);
      const j = rnd(0.9, 1.1);                                  // per-variant size of the "part"
      // [frequency Hz, amplitude, decay time s]: free-free bar ratios + plate-like modes,
      // several in close pairs for beating
      const table = [
        [1240, 0.30, 0.140], [1268, 0.22, 0.120],
        [3420, 0.55, 0.110], [3471, 0.35, 0.095],
        [4880, 0.45, 0.085],
        [6700, 0.60, 0.070], [6790, 0.40, 0.060],
        [8350, 0.45, 0.050],
        [11070, 0.35, 0.035], [13200, 0.22, 0.025],
      ];
      const modes = table.map(([f, a, tau]) => ({
        w: 2 * Math.PI * f * j * rnd(0.985, 1.015),
        a: a * rnd(0.75, 1.25),
        tau: tau * rnd(0.8, 1.25),
        ph: rnd(0, 2 * Math.PI),
      }));
      const hit2 = Math.floor(sr * rnd(0.003, 0.007));
      const hit2Gain = rnd(0.5, 0.8);
      let prev = 0;
      for (let i = 0; i < len; i++) {
        const t = i / sr;
        const n = Math.random() * 2 - 1;
        const hp = n - prev;                                   // bright, high-passed noise
        prev = n;
        let s = 2.4 * hp * Math.exp(-t / 0.0004);              // the click of impact
        let ring = 0;
        for (const m of modes) ring += m.a * Math.sin(m.w * t + m.ph) * Math.exp(-t / m.tau);
        // the ring is loudest right at the strike and drops fast, then a quieter tail rings on
        s += ring * (0.18 + 0.42 * Math.exp(-t / 0.012));
        if (i >= hit2) {                                       // second strike re-excites the metal
          const t2 = (i - hit2) / sr;
          s += hit2Gain * 1.3 * hp * Math.exp(-t2 / 0.0003);
          let r2 = 0;
          for (let k = 2; k < modes.length; k++) {
            const m = modes[k];
            r2 += m.a * Math.sin(m.w * 1.003 * t2 + m.ph * 1.7) * Math.exp(-t2 / (m.tau * 0.6));
          }
          s += hit2Gain * 0.35 * r2;
        }
        d[i] = s;
      }
      // light saturation for bite, normalize, short fade at the end
      let peak = 0;
      for (let i = 0; i < len; i++) peak = Math.max(peak, Math.abs(d[i]));
      for (let i = 0; i < len; i++) d[i] = Math.tanh(1.25 * d[i] / peak);
      peak = 0;
      for (let i = 0; i < len; i++) peak = Math.max(peak, Math.abs(d[i]));
      const fade = Math.floor(sr * 0.03);
      for (let i = 0; i < len; i++) d[i] *= (0.9 / peak) * Math.min(1, (len - i) / fade);
      return buf;
    }

    async loadSample(url) {
      try {
        const r = await fetch(url);
        if (!r.ok) throw new Error('HTTP ' + r.status);
        const decoded = await this.ctx.decodeAudioData(await r.arrayBuffer());
        this.buffers = [decoded];
        console.info(NAME + ': using flap sound sample ' + url);
      } catch (err) {
        console.warn(NAME + ': could not load sound sample "' + url + '" (' + err.message +
          '); using the built-in metal clack');
      }
    }

    /** true when the browser is still waiting for a click before it allows sound */
    blocked() { return this.enabled && (!this.ctx || this.ctx.state !== 'running'); }

    unlock() {
      if (!this.enabled) return;
      if (!this.ensureContext()) return;
      if (this.ctx.state !== 'running') this.ctx.resume();
    }

    setEnabled(on) {
      this.enabled = on;
      if (on) this.unlock();
    }

    setVolume(v) {
      this.volume = v;
      if (this.master) this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.02);
    }

    /** count = how many flaps landed this frame */
    play(count) {
      if (!this.enabled || !this.ctx || this.ctx.state !== 'running' || count === 0 || this.volume <= 0) return;
      const voices = Math.min(count, this.maxVoicesPerFrame);
      // loudness grows gently with the number of flaps, spread over a few voices
      const perVoice = 0.45 * Math.pow(count, 0.3) / voices;
      const now = this.ctx.currentTime;
      for (let v = 0; v < voices; v++) {
        const src = this.ctx.createBufferSource();
        src.buffer = this.buffers[Math.floor(Math.random() * this.buffers.length)];
        src.playbackRate.value = 0.94 + Math.random() * 0.14;
        const g = this.ctx.createGain();
        g.gain.value = perVoice * (0.8 + Math.random() * 0.4);
        src.connect(g).connect(this.master);
        src.start(now + (v === 0 ? 0 : Math.random() * 0.016));
      }
    }
  }

  // ------------------------------------------------------------------ settings memory
  const SETTINGS_KEY = NAME + '.settings';
  function loadSettings() {
    try { return JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') || {}; } catch (e) { return {}; }
  }
  function saveSettings(s) {
    try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch (e) { /* not available */ }
  }

  // speed steps (clock seconds per real second). 1 = real time.
  const SPEED_STEPS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30,
    40, 50, 60, 90, 120];

  function speedLabel(v) {
    if (v === 1) return '1× real time';
    return (v < 1 ? v.toFixed(2).replace(/0$/, '') : String(v)) + '×';
  }

  // ------------------------------------------------------------------ loading + UI
  function showMessage(html) {
    const box = document.getElementById('message');
    box.innerHTML = html;
    box.hidden = false;
  }

  async function fetchJSON(url) {
    const r = await fetch(url, { cache: 'no-store' });
    if (!r.ok) throw new Error(url + ': HTTP ' + r.status);
    return r.json();
  }

  function start(fieldsDoc, scheduleDoc) {
    document.getElementById('message').hidden = true;
    document.getElementById('loader').hidden = true;
    const host = document.getElementById('board');
    let board;
    try {
      board = new Board(fieldsDoc, scheduleDoc, host);
    } catch (err) {
      showMessage('<b>' + NAME + ' could not build the sign.</b><br>' + escapeHtml(err.message));
      throw err;
    }

    const saved = loadSettings();
    const soundCfg = Object.assign({ enabled: true, volume: 0.6 }, (fieldsDoc.display || {}).sound || {});
    const clacker = new Clacker({
      enabled: saved.soundOn !== undefined ? saved.soundOn : soundCfg.enabled,
      volume: saved.volume !== undefined ? saved.volume : soundCfg.volume,
      sampleFile: soundCfg.sampleFile,
      maxVoicesPerFrame: soundCfg.maxVoicesPerFrame,
    });
    // Speed is deliberately NOT remembered: every start runs at the schedule's speed
    // (real time, 1x). Only the sound settings are remembered.
    const remember = () => saveSettings({ soundOn: clacker.enabled, volume: clacker.volume });

    const $ = (id) => document.getElementById(id);
    const status = $('status');
    const btnFwd = $('btn-forward'), btnStop = $('btn-stop'), btnReset = $('btn-reset');
    const btnSound = $('btn-sound'), volume = $('volume'), volumeVal = $('volume-val');
    const btnSlower = $('btn-slower'), btnFaster = $('btn-faster'), btnRealtime = $('btn-realtime');
    const speedVal = $('speed-val');
    const unlockBanner = $('sound-unlock');

    const refresh = () => {
      btnFwd.classList.toggle('active', board.running);
      btnStop.classList.toggle('active', !board.running);
      status.textContent = (board.running ? 'Running' : 'Stopped') + ' · ' + clockTextSeconds(board.sim);
      speedVal.textContent = speedLabel(board.speed);
      btnRealtime.classList.toggle('active', board.speed === 1);
      btnSound.textContent = clacker.enabled ? 'Sound on' : 'Sound off';
      btnSound.classList.toggle('active', clacker.enabled);
      volume.value = Math.round(clacker.volume * 100);
      volumeVal.textContent = Math.round(clacker.volume * 100) + '%';
      volume.disabled = !clacker.enabled;
      unlockBanner.hidden = !clacker.blocked();
    };

    // speed: step through SPEED_STEPS (the JSON speed may be between steps; that's fine)
    const stepSpeed = (dir) => {
      let i;
      if (dir > 0) i = SPEED_STEPS.findIndex(s => s > board.speed + 1e-9);
      else { i = -1; SPEED_STEPS.forEach((s, k) => { if (s < board.speed - 1e-9) i = k; }); }
      if (i >= 0) board.speed = SPEED_STEPS[i];
      remember(); refresh();
    };
    btnSlower.onclick = () => stepSpeed(-1);
    btnFaster.onclick = () => stepSpeed(+1);
    btnRealtime.onclick = () => { board.speed = 1; remember(); refresh(); };

    btnFwd.onclick = () => { board.userTouched = true; board.forward(); refresh(); };
    btnStop.onclick = () => { board.userTouched = true; board.stop(); refresh(); };
    btnReset.onclick = () => { board.userTouched = true; board.reset(); refresh(); };
    btnSound.onclick = () => { clacker.setEnabled(!clacker.enabled); remember(); refresh(); };
    volume.oninput = () => {
      clacker.setVolume(volume.value / 100);
      volumeVal.textContent = volume.value + '%';
    };
    volume.onchange = () => { remember(); refresh(); };

    // Browsers only allow sound after the first click or key press on the page
    clacker.unlock();
    const unlock = () => { clacker.unlock(); setTimeout(refresh, 50); };
    window.addEventListener('pointerdown', unlock, true);
    window.addEventListener('keydown', unlock, true);

    window.addEventListener('keydown', (e) => {
      if (e.target && e.target.tagName === 'INPUT') return;
      if (e.code === 'Space' || e.key === 'r' || e.key === 'R') board.userTouched = true;
      if (e.code === 'Space') { e.preventDefault(); board.running ? board.stop() : board.forward(); refresh(); }
      else if (e.key === 'r' || e.key === 'R') { board.reset(); refresh(); }
      else if (e.key === '+' || e.key === '=' || e.key === ']') stepSpeed(+1);
      else if (e.key === '-' || e.key === '_' || e.key === '[') stepSpeed(-1);
      else if (e.key === '1') { board.speed = 1; remember(); refresh(); }
      else if (e.key === 'm' || e.key === 'M') { clacker.setEnabled(!clacker.enabled); remember(); refresh(); }
    });

    let last = performance.now();
    let lastStatus = 0;
    function frame(now) {
      const dt = Math.min(0.25, (now - last) / 1000);
      last = now;
      clacker.play(board.step(now, dt));
      if (now - lastStatus > 250) { refresh(); lastStatus = now; }
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
    refresh();
    // Start the master clock by itself a moment after loading (schedule clock.autoStart)
    const clock = scheduleDoc.clock || {};
    if (clock.autoStart !== false) {
      setTimeout(() => { if (!board.running && !board.userTouched) { board.forward(); refresh(); } },
        1000 * (clock.autoStartDelaySeconds !== undefined ? clock.autoStartDelaySeconds : 2));
    }
    window.CT40 = { board, clacker, clockText, clockTextSeconds, parseTime, fieldText };  // for tinkering in the console
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  }

  /** Fallback when the page is opened straight from disk and the browser blocks fetch() */
  function offerFilePicker(reason) {
    const loader = document.getElementById('loader');
    loader.hidden = false;
    document.getElementById('loader-reason').textContent = reason;
    const input = document.getElementById('loader-input');
    const drop = document.getElementById('loader-drop');
    const docs = {};
    const accept = async (files) => {
      for (const f of files) {
        try {
          const doc = JSON.parse(await f.text());
          if (doc.fields) docs.fields = doc;
          else if (doc.events) docs.schedule = doc;
        } catch (err) {
          showMessage('Could not read ' + escapeHtml(f.name) + ': ' + escapeHtml(err.message));
        }
      }
      document.getElementById('loader-got').textContent =
        'Fields file: ' + (docs.fields ? 'loaded' : 'still needed') + ' · Schedule file: ' +
        (docs.schedule ? 'loaded' : 'still needed');
      if (docs.fields && docs.schedule) start(docs.fields, docs.schedule);
    };
    input.onchange = () => accept(Array.from(input.files));
    drop.ondragover = (e) => { e.preventDefault(); drop.classList.add('over'); };
    drop.ondragleave = () => drop.classList.remove('over');
    drop.ondrop = (e) => { e.preventDefault(); drop.classList.remove('over'); accept(Array.from(e.dataTransfer.files)); };
  }

  async function main() {
    document.title = NAME;
    if (!THREE) {
      showMessage('three.js did not load. Check that the <code>vendor</code> folder is next to ' +
        NAME + '.html.');
      return;
    }
    const q = new URLSearchParams(location.search);
    const fieldsUrl = q.get('fields') || FIELDS_URL;
    const scheduleUrl = q.get('schedule') || SCHEDULE_URL;
    let fieldsDoc, scheduleDoc;
    try {
      [fieldsDoc, scheduleDoc] = await Promise.all([fetchJSON(fieldsUrl), fetchJSON(scheduleUrl)]);
    } catch (err) {
      const fromDisk = location.protocol === 'file:';
      offerFilePicker(fromDisk
        ? 'This page was opened straight from disk, and the browser will not let it read the JSON files by itself.'
        : 'The JSON files could not be loaded (' + err.message + ').');
      return;
    }
    start(fieldsDoc, scheduleDoc);
  }

  window.addEventListener('DOMContentLoaded', main);
})();

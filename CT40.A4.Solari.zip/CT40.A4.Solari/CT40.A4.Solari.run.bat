@echo off
rem CT40.A4.Solari - start the sign (local web server + browser)
cd /d "%~dp0"
where py >nul 2>nul && (py CT40.A4.Solari.server.py %* & goto :eof)
where python >nul 2>nul && (python CT40.A4.Solari.server.py %* & goto :eof)
echo Python was not found. Install it from https://www.python.org or open CT40.A4.Solari.html
echo directly and choose the two JSON files when asked.
pause

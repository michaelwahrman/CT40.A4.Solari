#!/bin/sh
# CT40.A4.Solari - start the sign (local web server + browser)
cd "$(dirname "$0")" && exec python3 CT40.A4.Solari.server.py "$@"
